package com.demo.dao;

import java.util.List;

public interface DemoDAO {

	List<String> getData();

}
