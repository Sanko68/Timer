package com.demo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class DemoDAOImpl implements DemoDAO {

	@Override
	public List<String> getData() {
		List<String> list = new ArrayList<String>();
		list.add("1st value");
		list.add("2nd value");
		list.add("3rd value");
		list.add("4th value");
		return list;
	}

}
