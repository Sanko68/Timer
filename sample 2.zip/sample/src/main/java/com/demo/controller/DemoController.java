package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.demo.service.DemoService;

@RestController
public class DemoController {

	@Autowired
	private DemoService demoServiceImpl;

	@RequestMapping("/home")
	public String home() {
		
		return "home";
	}

	@RequestMapping("/")
	public ModelAndView welcome() {
		List<String> list = demoServiceImpl.getData();
		System.out.println("List "+list);
		return new ModelAndView("home","list",list);
	}
	

	
}
