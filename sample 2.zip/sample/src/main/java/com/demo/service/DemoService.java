package com.demo.service;

import java.util.List;

public interface DemoService {

	List<String> getData();

}
